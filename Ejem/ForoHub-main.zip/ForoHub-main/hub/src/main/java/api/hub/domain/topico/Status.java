package api.hub.domain.topico;

public enum Status {
    ACTIVO,
    INACTIVO
}