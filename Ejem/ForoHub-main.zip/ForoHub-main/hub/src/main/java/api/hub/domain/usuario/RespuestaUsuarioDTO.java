package api.hub.domain.usuario;

public record RespuestaUsuarioDTO(
        Long id,
        String name
) {

}