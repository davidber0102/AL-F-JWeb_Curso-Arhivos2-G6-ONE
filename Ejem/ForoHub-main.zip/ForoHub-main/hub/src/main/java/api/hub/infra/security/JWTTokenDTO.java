package api.hub.infra.security;

public record JWTTokenDTO(String token) {
}