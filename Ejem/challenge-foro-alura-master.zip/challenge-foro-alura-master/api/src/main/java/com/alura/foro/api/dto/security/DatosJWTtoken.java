package com.alura.foro.api.dto.security;

public record DatosJWTtoken(String jwtToken) {
}
