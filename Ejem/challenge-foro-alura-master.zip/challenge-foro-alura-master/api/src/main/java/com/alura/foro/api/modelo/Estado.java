package com.alura.foro.api.modelo;

public enum Estado {

    NO_RESPONDIDO,
    NO_SOLUCIONADO,
    SOLUCIONADO,
    CERRADO;

}
