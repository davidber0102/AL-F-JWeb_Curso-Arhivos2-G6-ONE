package com.alura.foro.api.modelo;

public enum Tipo {

    ROLE_ADMIN,
    ROLE_MOD,
    ROLE_USER

}
