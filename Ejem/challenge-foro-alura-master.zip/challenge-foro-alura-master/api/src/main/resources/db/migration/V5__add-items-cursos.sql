INSERT INTO cursos (nombre, categoria) VALUES ('Primeros Pasos', 'Lógica de Programación');
INSERT INTO cursos (nombre, categoria) VALUES ('HTML5 y CSS3 - parte 1', 'Primeras Páginas Web');
INSERT INTO cursos (nombre, categoria) VALUES ('Git y Github', 'Git');
INSERT INTO cursos (nombre, categoria) VALUES ('Java JRE y JDK', 'Java y Orientación a Objetos');